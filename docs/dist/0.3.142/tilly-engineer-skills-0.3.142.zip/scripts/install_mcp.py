#!/usr/bin/env python3
"""Install project-scoped TES Cortex MCP activation files."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import tomllib
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import field_reports
import tes_bundle


SCRIPT_PATH = Path(__file__).resolve()
ROOT = SCRIPT_PATH.parents[1]
VERSION = "0.3.142"
SERVER_NAME = "tes-cortex"
BIN_DIR = Path(".tes/bin")
SERVER_FILES = (
    "install_mcp.py",
    "cortex.py",
    "cortex_mcp.py",
    "cortex_embed.mjs",
    "scope_contract.py",
    "event_ledger.py",
    "checkpoint.py",
    "consolidation_gate.py",
    "field_reports.py",
    "mantra_gate.py",
    "mantra_gate_adoption_oracle.py",
    "tes_install.py",
    "tes_update.py",
    "tes_legacy_retirement.py",
    "root_context.py",
    "tes_init.py",
    "project_context_oracle.py",
    "project_alignment_oracle.py",
    "tes_map.py",
    "tes_map_oracle.py",
    "tes_open_obsidian.py",
    "command_trigger_oracle.py",
    "tes_bundle.py",
    "materialize_adapter.py",
)
ADAPTERS = ("codex", "claude", "cursor", "vscode")
JSON_CONFIG_PATHS = {
    "claude": Path(".mcp.json"),
    "cursor": Path(".cursor/mcp.json"),
    "vscode": Path(".vscode/mcp.json"),
}
JSON_SERVER_KEYS = {
    "claude": "mcpServers",
    "cursor": "mcpServers",
    "vscode": "servers",
}


def utc_stamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def rel(path: Path, target: Path) -> str:
    try:
        return path.relative_to(target).as_posix()
    except ValueError:
        return str(path)


def selected_adapters(adapter: str) -> list[str]:
    if adapter == "all":
        return list(ADAPTERS)
    return [adapter]


def source_script(name: str) -> Path:
    path = ROOT / "scripts" / name
    if not path.exists():
        path = SCRIPT_PATH.parent / name
    if not path.exists():
        raise FileNotFoundError(f"missing source script/helper: {name}")
    return path


def source_package_mode() -> bool:
    return (ROOT / "scripts/install_mcp.py").exists()


def python_command() -> str:
    executable = Path(sys.executable)
    if executable.is_absolute() and executable.exists():
        return str(executable)
    resolved = shutil.which(sys.executable) or shutil.which("python3")
    return resolved or "python3"


def target_script(target: Path, name: str) -> str:
    return str((target / BIN_DIR / name).resolve())


def backup_file(path: Path) -> Path:
    backup = path.with_name(f"{path.name}.bak-{utc_stamp()}")
    shutil.copy2(path, backup)
    return backup


def write_text_file(path: Path, text: str, dry_run: bool, backup: bool) -> dict[str, str]:
    encoded = text.encode("utf-8")
    existed = path.exists()
    if path.exists():
        current = path.read_bytes()
        if current == encoded:
            return {"path": str(path), "action": "skip-identical", "sha": sha256_bytes(encoded)}
        if dry_run:
            return {"path": str(path), "action": "would-update", "sha": sha256_bytes(encoded)}
        backup_path = backup_file(path) if backup else None
    else:
        if dry_run:
            return {"path": str(path), "action": "would-create", "sha": sha256_bytes(encoded)}
        backup_path = None

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    action = "update" if existed else "create"
    result = {"path": str(path), "action": action, "sha": sha256_bytes(encoded)}
    if backup_path:
        result["backup"] = str(backup_path)
    return result


def install_server_files(target: Path, dry_run: bool, overwrite: bool, backup: bool) -> tuple[list[dict[str, str]], list[str]]:
    actions: list[dict[str, str]] = []
    failures: list[str] = []
    for name in SERVER_FILES:
        try:
            source = source_script(name)
        except FileNotFoundError as exc:
            failures.append(str(exc))
            continue
        target_path = target / BIN_DIR / name
        source_sha = sha256_file(source)
        if target_path.exists():
            target_sha = sha256_file(target_path)
            if target_sha == source_sha:
                actions.append(
                    {
                        "path": rel(target_path, target),
                        "source": str(source),
                        "action": "skip-identical",
                        "sha": source_sha,
                    }
                )
                continue
            if not overwrite:
                failures.append(f"conflicting MCP helper: {rel(target_path, target)}")
                continue
            if dry_run:
                actions.append(
                    {
                        "path": rel(target_path, target),
                        "source": str(source),
                        "action": "would-overwrite",
                        "sha": source_sha,
                    }
                )
                continue
            backup_path = backup_file(target_path) if backup else None
        else:
            if dry_run:
                actions.append(
                    {
                        "path": rel(target_path, target),
                        "source": str(source),
                        "action": "would-copy",
                        "sha": source_sha,
                    }
                )
                continue
            backup_path = None

        target_path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target_path)
        action = {
            "path": rel(target_path, target),
            "source": str(source),
            "action": "overwrite" if backup_path else "copy",
            "sha": source_sha,
        }
        if backup_path:
            action["backup"] = rel(backup_path, target)
        actions.append(action)
    return actions, failures


def codex_snippet(target: Path, read_only: bool = False) -> str:
    args = [
        json.dumps(target_script(target, "cortex_mcp.py")),
        json.dumps("--target"),
        json.dumps(str(target)),
    ]
    if read_only:
        args.append(json.dumps("--read-only"))
    return f"""[mcp_servers.tes-cortex]
command = {json.dumps(python_command())}
args = [{", ".join(args)}]
cwd = {json.dumps(str(target))}
startup_timeout_sec = 10
tool_timeout_sec = 60
enabled = true
"""


def merge_codex_config(
    target: Path,
    dry_run: bool,
    overwrite: bool,
    backup: bool,
    read_only: bool,
) -> tuple[dict[str, str] | None, str | None]:
    path = target / ".codex/config.toml"
    snippet = codex_snippet(target, read_only)
    if not path.exists():
        action = write_text_file(path, snippet, dry_run, backup)
        action["path"] = rel(path, target)
        return action, None

    text = path.read_text(encoding="utf-8")
    if "[mcp_servers.tes-cortex]" in text:
        if snippet.strip() in text:
            return {"path": rel(path, target), "action": "skip-identical"}, None
        if not overwrite:
            return None, "conflicting Codex MCP config: .codex/config.toml"
        updated = replace_toml_section(text, "[mcp_servers.tes-cortex]", snippet)
    else:
        updated = text.rstrip() + "\n\n" + snippet
    action = write_text_file(path, updated, dry_run, backup)
    action["path"] = rel(path, target)
    return action, None


def replace_toml_section(text: str, header: str, replacement: str) -> str:
    lines = text.splitlines()
    start = next(i for i, line in enumerate(lines) if line.strip() == header)
    end = len(lines)
    for idx in range(start + 1, len(lines)):
        if lines[idx].startswith("[") and lines[idx].endswith("]"):
            end = idx
            break
    return "\n".join([*lines[:start], replacement.rstrip(), *lines[end:]]).rstrip() + "\n"


def json_config(adapter: str, target: Path, read_only: bool = False) -> dict[str, Any]:
    args = [target_script(target, "cortex_mcp.py"), "--target", str(target)]
    if read_only:
        args.append("--read-only")
    return {
        "type": "stdio",
        "command": python_command(),
        "args": args,
        "env": {},
    }


def merge_json_config(
    target: Path,
    adapter: str,
    dry_run: bool,
    overwrite: bool,
    backup: bool,
    read_only: bool,
) -> tuple[dict[str, str] | None, str | None]:
    path = target / JSON_CONFIG_PATHS[adapter]
    server_key = JSON_SERVER_KEYS[adapter]
    desired_server = json_config(adapter, target, read_only)
    data: dict[str, Any]
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            return None, f"invalid JSON in {rel(path, target)}: {exc}"
        if not isinstance(data, dict):
            return None, f"{rel(path, target)} must contain a JSON object"
    else:
        data = {}

    servers = data.setdefault(server_key, {})
    if not isinstance(servers, dict):
        return None, f"{rel(path, target)} {server_key} must be an object"
    existing = servers.get(SERVER_NAME)
    if existing == desired_server:
        return {"path": rel(path, target), "action": "skip-identical"}, None
    if existing is not None and not overwrite:
        return None, f"conflicting {adapter} MCP config: {rel(path, target)}"

    servers[SERVER_NAME] = desired_server
    text = json.dumps(data, indent=2, sort_keys=True) + "\n"
    action = write_text_file(path, text, dry_run, backup)
    action["path"] = rel(path, target)
    return action, None


def validate_config_registration(target: Path, adapter: str, read_only: bool) -> tuple[dict[str, str], str | None]:
    if adapter == "codex":
        path = target / ".codex/config.toml"
        if not path.exists():
            return {"adapter": adapter, "path": rel(path, target), "status": "FAIL"}, "missing Codex MCP config: .codex/config.toml"
        try:
            data = tomllib.loads(path.read_text(encoding="utf-8"))
        except tomllib.TOMLDecodeError as exc:
            return {"adapter": adapter, "path": rel(path, target), "status": "FAIL"}, f"invalid TOML in .codex/config.toml: {exc}"
        server = data.get("mcp_servers", {}).get(SERVER_NAME) if isinstance(data.get("mcp_servers"), dict) else None
        if not isinstance(server, dict):
            return {"adapter": adapter, "path": rel(path, target), "status": "FAIL"}, "Codex MCP config missing tes-cortex server"
        args = server.get("args")
        if (
            server.get("command") != python_command()
            or server.get("cwd") != str(target)
            or not isinstance(args, list)
            or target_script(target, "cortex_mcp.py") not in args
            or str(target) not in args
        ):
            return {"adapter": adapter, "path": rel(path, target), "status": "FAIL"}, "Codex MCP config has invalid tes-cortex command or args"
        if read_only and "--read-only" not in args:
            return {"adapter": adapter, "path": rel(path, target), "status": "FAIL"}, "Codex read-only MCP config missing --read-only"
        if not read_only and "--read-only" in args:
            return {"adapter": adapter, "path": rel(path, target), "status": "FAIL"}, "Codex default MCP config must expose governed remember tools"
        return {"adapter": adapter, "path": rel(path, target), "status": "PASS", "server": SERVER_NAME}, None

    path = target / JSON_CONFIG_PATHS[adapter]
    server_key = JSON_SERVER_KEYS[adapter]
    if not path.exists():
        return {"adapter": adapter, "path": rel(path, target), "status": "FAIL"}, f"missing {adapter} MCP config: {rel(path, target)}"
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return {"adapter": adapter, "path": rel(path, target), "status": "FAIL"}, f"invalid JSON in {rel(path, target)}: {exc}"
    if not isinstance(data, dict):
        return {"adapter": adapter, "path": rel(path, target), "status": "FAIL"}, f"{rel(path, target)} must contain a JSON object"
    servers = data.get(server_key)
    if not isinstance(servers, dict):
        return {"adapter": adapter, "path": rel(path, target), "status": "FAIL"}, f"{rel(path, target)} {server_key} must be an object"
    expected = json_config(adapter, target, read_only)
    actual = servers.get(SERVER_NAME)
    if actual != expected:
        return {"adapter": adapter, "path": rel(path, target), "status": "FAIL"}, f"{rel(path, target)} missing expected tes-cortex server registration"
    return {"adapter": adapter, "path": rel(path, target), "status": "PASS", "server": SERVER_NAME, "server_key": server_key}, None


def validate_config_registrations(target: Path, adapters: list[str], read_only: bool) -> tuple[list[dict[str, str]], list[str]]:
    registrations: list[dict[str, str]] = []
    failures: list[str] = []
    for adapter in adapters:
        registration, failure = validate_config_registration(target, adapter, read_only)
        registrations.append(registration)
        if failure:
            failures.append(failure)
    return registrations, failures


def install_configs(
    target: Path,
    adapters: list[str],
    dry_run: bool,
    overwrite: bool,
    backup: bool,
    read_only: bool,
) -> tuple[list[dict[str, str]], list[str]]:
    actions: list[dict[str, str]] = []
    failures: list[str] = []
    for adapter in adapters:
        if adapter == "codex":
            action, failure = merge_codex_config(target, dry_run, overwrite, backup, read_only)
        else:
            action, failure = merge_json_config(target, adapter, dry_run, overwrite, backup, read_only)
        if failure:
            failures.append(failure)
        if action:
            action["adapter"] = adapter
            actions.append(action)
    return actions, failures


def require_confirmation(args: argparse.Namespace) -> bool:
    if args.dry_run or args.yes:
        return True
    if not sys.stdin.isatty():
        print("[install-mcp] FAIL")
        print("- write mode requires --yes when stdin is not interactive")
        return False
    answer = input("Install TES Cortex MCP into target project? Type 'yes' to continue: ")
    if answer.strip().lower() != "yes":
        print("[install-mcp] CANCELLED")
        return False
    return True


def install(args: argparse.Namespace) -> int:
    target = args.target.expanduser().resolve()
    if not target.exists() or not target.is_dir():
        print("[install-mcp] FAIL")
        print(f"- target is not a directory: {target}")
        return 1

    if not require_confirmation(args):
        return 1

    if not args.dry_run:
        field_reports.ensure_git_exclude(target)

    read_only = bool(args.read_only or args.disable_writes)
    adapters = selected_adapters(args.adapter)
    bundle_adapter = "all" if args.adapter == "vscode" else args.adapter
    bundle_stage = (
        tes_bundle.stage_preferred_bundle(target, dry_run=args.dry_run, adapter=bundle_adapter)
        if source_package_mode()
        else {
            "version": VERSION,
            "status": "SKIP",
            "source": "installed-helper",
            "reason": "source package unavailable; using installed .tes/bin helpers",
        }
    )
    server_actions, server_failures = install_server_files(target, args.dry_run, args.overwrite, not args.no_backup)
    config_actions, config_failures = (
        ([], [])
        if args.helpers_only
        else install_configs(target, adapters, args.dry_run, args.overwrite, not args.no_backup, read_only)
    )
    config_registrations, registration_failures = (
        ([], [])
        if args.helpers_only or args.dry_run or config_failures
        else validate_config_registrations(target, adapters, read_only)
    )
    bundle_failures = bundle_stage.get("failures", []) if bundle_stage.get("status") == "FAIL" else []
    failures = [*bundle_failures, *server_failures, *config_failures, *registration_failures]
    status = "FAIL" if failures else ("DRY-RUN" if args.dry_run else "INSTALLED")
    result = {
        "version": VERSION,
        "status": status,
        "target": str(target),
        "adapter": args.adapter,
        "route": args.adapter,
        "helpers_only": args.helpers_only,
        "governed_writes": not read_only,
        "write_capable": not read_only,
        "read_only": read_only,
        "bundle_stage": bundle_stage,
        "server": SERVER_NAME,
        "server_files": server_actions,
        "configs": config_actions,
        "config_registrations": config_registrations,
        "failures": failures,
    }
    print(json.dumps(result, indent=2))
    if not args.dry_run:
        field_reports.safe_record_event(
            target,
            "install_mcp",
            status,
            "mcp",
            "cli",
            details={
                "adapter": args.adapter,
                "route": args.adapter,
                "helpers_only": args.helpers_only,
                "governed_writes": not read_only,
                "write_capable": not read_only,
                "read_only": read_only,
                "dry_run": args.dry_run,
                "failures": len(failures),
            },
        )
    if failures:
        if not args.json_only:
            print("[install-mcp] FAIL")
        return 2
    if not args.json_only:
        print("[install-mcp] PASS")
    return 0


def self_test() -> int:
    with tempfile.TemporaryDirectory(prefix="tes-mcp-install-") as tempdir:
        target = Path(tempdir).resolve()
        result = subprocess.run(
            [sys.executable, str(ROOT / "scripts/cortex.py"), "init", "--target", str(target)],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=False,
        )
        failures: list[str] = []
        if result.returncode != 0:
            failures.append("cortex init failed")
        (target / ".vscode").mkdir(parents=True, exist_ok=True)
        (target / ".vscode/mcp.json").write_text(
            json.dumps(
                {
                    "servers": {
                        "existing-server": {
                            "type": "http",
                            "url": "https://example.invalid/mcp",
                        }
                    }
                },
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )
        install_result = subprocess.run(
            [sys.executable, __file__, "--target", str(target), "--adapter", "all", "--yes"],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=False,
        )
        if install_result.returncode != 0:
            failures.append("install all failed")
            failures.extend(install_result.stdout.splitlines())
            failures.extend(install_result.stderr.splitlines())
        for relpath in (
            ".tes/bin/install_mcp.py",
            ".tes/bin/cortex.py",
            ".tes/bin/cortex_mcp.py",
            ".tes/bin/cortex_embed.mjs",
            ".tes/bin/field_reports.py",
            ".tes/bin/tes_install.py",
            ".tes/bin/tes_update.py",
            ".tes/bin/tes_legacy_retirement.py",
            ".tes/bin/root_context.py",
            ".tes/bin/tes_init.py",
            ".tes/bin/project_context_oracle.py",
            ".tes/bin/project_alignment_oracle.py",
            ".tes/bin/tes_map.py",
            ".tes/bin/tes_map_oracle.py",
            ".tes/bin/tes_open_obsidian.py",
            ".tes/bin/command_trigger_oracle.py",
            ".tes/bin/tes_bundle.py",
            ".tes/bin/materialize_adapter.py",
            f".tes/setup/{VERSION}/tes-bundle-manifest.json",
            ".codex/config.toml",
            ".mcp.json",
            ".cursor/mcp.json",
            ".vscode/mcp.json",
        ):
            if not (target / relpath).exists():
                failures.append(f"missing installed path: {relpath}")
        mcp_self_test = subprocess.run(
            [sys.executable, str(target / ".tes/bin/cortex_mcp.py"), "--self-test"],
            cwd=target,
            text=True,
            capture_output=True,
            check=False,
        )
        if mcp_self_test.returncode != 0:
            failures.append("installed cortex_mcp.py --self-test failed")
            failures.extend(mcp_self_test.stdout.splitlines())
            failures.extend(mcp_self_test.stderr.splitlines())
        codex_config = (target / ".codex/config.toml").read_text(encoding="utf-8")
        if "--read-only" in codex_config:
            failures.append("default Codex MCP install must expose governed remember tools")
        if "--enable-writes" in codex_config:
            failures.append("default Codex MCP install must not need legacy --enable-writes")
        codex_data = tomllib.loads(codex_config)
        codex_server = codex_data.get("mcp_servers", {}).get(SERVER_NAME)
        if not isinstance(codex_server, dict):
            failures.append("default Codex MCP install must create mcp_servers.tes-cortex")
        else:
            codex_args = codex_server.get("args")
            if codex_server.get("command") != python_command():
                failures.append("default Codex MCP install must use the active Python executable")
            if codex_server.get("cwd") != str(target):
                failures.append("default Codex MCP install must use absolute target cwd")
            if not isinstance(codex_args, list) or target_script(target, "cortex_mcp.py") not in codex_args or str(target) not in codex_args:
                failures.append("default Codex MCP install must use absolute target args")
        for relpath in (".mcp.json", ".cursor/mcp.json", ".vscode/mcp.json"):
            data = json.loads((target / relpath).read_text(encoding="utf-8"))
            server_key = "servers" if relpath == ".vscode/mcp.json" else "mcpServers"
            server = data[server_key][SERVER_NAME]
            args = server["args"]
            if server.get("command") != python_command():
                failures.append(f"default {relpath} MCP install must use the active Python executable")
            if target_script(target, "cortex_mcp.py") not in args or str(target) not in args:
                failures.append(f"default {relpath} MCP install must use absolute target args")
            if any(str(arg).startswith("${workspaceFolder}") or str(arg) in {".", ".tes/bin/cortex_mcp.py"} for arg in args):
                failures.append(f"default {relpath} MCP install must not depend on host cwd or workspace interpolation")
            if "--read-only" in args:
                failures.append(f"default {relpath} MCP install must expose governed remember tools")
            if "--enable-writes" in args:
                failures.append(f"default {relpath} MCP install must not need legacy --enable-writes")
            if relpath == ".vscode/mcp.json" and "existing-server" not in data["servers"]:
                failures.append("VS Code MCP install must preserve existing servers")

        (target / ".vscode/mcp.json").unlink()
        installed_repair_result = subprocess.run(
            [
                sys.executable,
                str(target / ".tes/bin/install_mcp.py"),
                "--target",
                str(target),
                "--adapter",
                "vscode",
                "--yes",
                "--json-only",
            ],
            cwd=target,
            text=True,
            capture_output=True,
            check=False,
        )
        if installed_repair_result.returncode != 0:
            failures.append("installed helper MCP repair failed")
            failures.extend(installed_repair_result.stdout.splitlines())
            failures.extend(installed_repair_result.stderr.splitlines())
        else:
            try:
                repair_payload = json.loads(installed_repair_result.stdout)
            except json.JSONDecodeError as exc:
                failures.append(f"installed helper MCP repair returned invalid JSON: {exc}")
            else:
                registrations = repair_payload.get("config_registrations")
                registration_items = registrations if isinstance(registrations, list) else []
                if repair_payload.get("status") != "INSTALLED":
                    failures.append("installed helper MCP repair must return INSTALLED")
                if repair_payload.get("bundle_stage", {}).get("source") != "installed-helper":
                    failures.append("installed helper MCP repair must use installed-helper source")
                if not any(
                    isinstance(item, dict)
                    and item.get("adapter") == "vscode"
                    and item.get("status") == "PASS"
                    and item.get("server_key") == "servers"
                    for item in registration_items
                ):
                    failures.append("installed helper MCP repair must validate VS Code server registration")
            repaired = target / ".vscode/mcp.json"
            if not repaired.exists():
                failures.append("installed helper MCP repair did not recreate .vscode/mcp.json")

    with tempfile.TemporaryDirectory(prefix="tes-mcp-read-only-install-") as tempdir:
        target = Path(tempdir).resolve()
        init_result = subprocess.run(
            [sys.executable, str(ROOT / "scripts/cortex.py"), "init", "--target", str(target)],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=False,
        )
        if init_result.returncode != 0:
            failures.append("read-only cortex init failed")
        read_only_install_result = subprocess.run(
            [
                sys.executable,
                __file__,
                "--target",
                str(target),
                "--adapter",
                "all",
                "--read-only",
                "--yes",
            ],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=False,
        )
        if read_only_install_result.returncode != 0:
            failures.append("read-only install all failed")
            failures.extend(read_only_install_result.stdout.splitlines())
            failures.extend(read_only_install_result.stderr.splitlines())
        elif "--read-only" not in (target / ".codex/config.toml").read_text(encoding="utf-8"):
            failures.append("read-only Codex MCP install must include --read-only")
        for relpath in (".mcp.json", ".cursor/mcp.json", ".vscode/mcp.json"):
            if not (target / relpath).exists():
                failures.append(f"read-only install missing config: {relpath}")
                continue
            data = json.loads((target / relpath).read_text(encoding="utf-8"))
            server_key = "servers" if relpath == ".vscode/mcp.json" else "mcpServers"
            args = data[server_key][SERVER_NAME]["args"]
            if "--read-only" not in args:
                failures.append(f"read-only {relpath} MCP install must include --read-only")

    with tempfile.TemporaryDirectory(prefix="tes-mcp-legacy-enable-install-") as tempdir:
        target = Path(tempdir).resolve()
        init_result = subprocess.run(
            [sys.executable, str(ROOT / "scripts/cortex.py"), "init", "--target", str(target)],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=False,
        )
        if init_result.returncode != 0:
            failures.append("legacy-enable cortex init failed")
        legacy_install_result = subprocess.run(
            [
                sys.executable,
                __file__,
                "--target",
                str(target),
                "--adapter",
                "all",
                "--enable-writes",
                "--yes",
            ],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=False,
        )
        if legacy_install_result.returncode != 0:
            failures.append("legacy --enable-writes install failed")
            failures.extend(legacy_install_result.stdout.splitlines())
            failures.extend(legacy_install_result.stderr.splitlines())
        else:
            if "--read-only" in (target / ".codex/config.toml").read_text(encoding="utf-8"):
                failures.append("legacy --enable-writes install must not create read-only config")
            vscode_args = json.loads((target / ".vscode/mcp.json").read_text(encoding="utf-8"))["servers"][SERVER_NAME]["args"]
            if "--read-only" in vscode_args:
                failures.append("legacy --enable-writes install must not create read-only VS Code config")

    with tempfile.TemporaryDirectory(prefix="tes-mcp-helpers-only-") as tempdir:
        target = Path(tempdir).resolve()
        helpers_only_result = subprocess.run(
            [sys.executable, __file__, "--target", str(target), "--adapter", "all", "--helpers-only", "--yes", "--json-only"],
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=False,
        )
        if helpers_only_result.returncode != 0:
            failures.append("helpers-only install failed")
            failures.extend(helpers_only_result.stdout.splitlines())
            failures.extend(helpers_only_result.stderr.splitlines())
        else:
            try:
                payload = json.loads(helpers_only_result.stdout)
            except json.JSONDecodeError as exc:
                failures.append(f"helpers-only --json-only returned invalid JSON: {exc}")
            else:
                if payload.get("helpers_only") is not True:
                    failures.append("helpers-only install must mark helpers_only=true")
                if payload.get("configs"):
                    failures.append("helpers-only install must not write MCP configs")
        for relpath in SERVER_FILES:
            if not (target / BIN_DIR / relpath).exists():
                failures.append(f"helpers-only install missing helper: {relpath}")
        for relpath in (".codex/config.toml", ".mcp.json", ".cursor/mcp.json", ".vscode/mcp.json"):
            if (target / relpath).exists():
                failures.append(f"helpers-only install wrote config: {relpath}")
        for relpath in (
            "root_context.py",
            "tes_update.py",
            "tes_init.py",
            "project_context_oracle.py",
            "project_alignment_oracle.py",
            "tes_map.py",
            "tes_map_oracle.py",
            "tes_open_obsidian.py",
            "command_trigger_oracle.py",
        ):
            helper_self_test = subprocess.run(
                [sys.executable, str(target / BIN_DIR / relpath), "--self-test"],
                cwd=target,
                text=True,
                capture_output=True,
                check=False,
            )
            if helper_self_test.returncode != 0:
                failures.append(f"installed helper self-test failed: {relpath}")
                failures.extend(helper_self_test.stdout.splitlines())
                failures.extend(helper_self_test.stderr.splitlines())
                continue
            json_text = "\n".join(
                line for line in helper_self_test.stdout.splitlines()
                if not line.startswith("[")
            )
            try:
                payload = json.loads(json_text)
            except json.JSONDecodeError as exc:
                failures.append(f"installed helper self-test returned invalid JSON: {relpath}: {exc}")
                continue
            if payload.get("self_test_mode") != "installed":
                failures.append(f"installed helper self-test must report installed mode: {relpath}")
            if payload.get("coverage") != "installed-helper-contract":
                failures.append(f"installed helper self-test must report installed coverage: {relpath}")

    print(json.dumps({"status": "FAIL" if failures else "PASS", "failures": failures}, indent=2))
    if failures:
        print("[install-mcp] FAIL")
        return 1
    print("[install-mcp] PASS")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--adapter", default="all", choices=["all", *ADAPTERS])
    parser.add_argument("--target", type=Path, default=Path.cwd())
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--yes", action="store_true", help="confirm writes without an interactive prompt")
    parser.add_argument("--overwrite", action="store_true", help="replace existing tes-cortex MCP entries")
    parser.add_argument(
        "--enable-writes",
        action="store_true",
        help="compatibility flag; governed Cortex remember MCP tools are enabled by default",
    )
    parser.add_argument("--read-only", action="store_true", help="install MCP config with governed remember tools hidden")
    parser.add_argument("--disable-writes", action="store_true", help="alias for --read-only")
    parser.add_argument("--helpers-only", action="store_true", help="copy only TES helper files under .tes/bin/**")
    parser.add_argument("--no-backup", action="store_true", help="do not create .bak-* files before overwrite")
    parser.add_argument("--json-only", action="store_true")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()

    if args.self_test:
        return self_test()
    if args.enable_writes and (args.read_only or args.disable_writes):
        parser.error("--enable-writes cannot be combined with --read-only/--disable-writes")
    return install(args)


if __name__ == "__main__":
    sys.exit(main())
