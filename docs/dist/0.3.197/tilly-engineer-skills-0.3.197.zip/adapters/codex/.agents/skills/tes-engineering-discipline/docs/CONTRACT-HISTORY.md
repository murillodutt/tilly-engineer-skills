# TES Engineering Discipline Contract History

## Purpose

`tes-engineering-discipline` is the maturity-aware engineering discipline anchor across TES authoring work.

## Why This Skill Exists

Bootloaders stay thin; behavioral depth loads on demand. This skill prevents ambiguous scope, false completion, and governance-only cycles without replacing runtime oracles.

## Contracts Preserved

- Core contract: assumptions visible, scope smaller, edits surgical, success falsifiable.
- Default material work to Birth maturity unless promoted with evidence.
- Mantra Gate for destructive, remote, release, sync, secret-bearing, or high-impact state changes; ordinary local edits do not block on markers or skill loading.
- `/tes-prospect`, `/tes-mine`, and `/tes-goal-maestro` require explicit invocation.
- Gate Zero arbitrates gate tension by binary-hard declared-contract evidence; collisions are escalated, never resolved silently.
- Effort is an orthogonal axis: `Premium` raises rigor per line, never scope.
- Maturity is classificatory: the artifact is born at the converged layer.

## Known Failure Modes Prevented

- Hidden assumptions and inflated scope.
- Claiming success without oracle.
- Activating prospect, mine, or goal-maestro from broad natural language.
- Duplicating full gate tables in every bootloader.
- The broad default winning gate tension over a source-nameable declared contract.
- Treating user-facing craft as a scope question with no effort axis.
- "Build small then rebuild" temporal trap of maturity.
- Adjective-as-criteria and graded effort decisions.

## Relationship To Other Skills

All TES work operates under this discipline. `tes-prospect`, `tes-mine`, and `tes-goal-maestro` add explicit opt-in reasoning modes and must not be activated from broad natural language.

## Changelog

| Date | Change | Evidence | Confidence |
|------|--------|----------|------------|
| 2026-04-01 | Created guidelines skill as discipline anchor. | TES core bootloader split. | high |
| 2026-06-08 | Added contract history per Tilly skill standard. | Documentation authority tiers program. | high |
| 2026-06-15 | Added Gate Zero, the Effort Gate, and classificatory maturity language. | Discipline oracle fixtures and canary findings. | high |
| 2026-06-24 | Re-scoped Mantra Gate to risk-scoped safety behavior. | Maintainer audit and local/source discipline alignment. | high |

## Do Not Lose

Guidelines govern how work is done; they do not replace project truth, runtime checks, or explicit user authorization for risky actions.
