---
name: tes-engineering-discipline
description: Apply a four-gate engineering discipline to non-trivial coding, review, refactor, or instruction-migration work so assumptions are explicit, scope stays small, diffs remain surgical, and success is verified by a concrete oracle.
---

# Tilly Engineering Discipline

Operational contract:

```text
Assumptions visible. Scope smaller. Edits surgical. Success falsifiable.
```

Use this skill for non-trivial coding, review, refactor, debugging, migration,
or agent-instruction work. Skip the full ceremony for obvious one-line fixes,
but keep the spirit.

## Four Gates

| Gate | Rule | Failure Blocked |
|------|------|-----------------|
| Think Before Coding | Name facts, assumptions, ambiguity, tradeoffs, and blockers before acting | Silent wrong interpretation |
| Simplicity First | Delete speculative scope before adding machinery | Overbuilt code and API bloat |
| Surgical Changes | Touch only request-traceable lines and self-created orphans | Drive-by edits and style churn |
| Goal-Driven Execution | Define and run a falsifiable oracle before closure | False completion |

## Discipline Packet

Use this compact packet when the task is material:

```yaml
engineering_discipline:
  assumptions:
  ambiguity:
  stack_surface:
  simplest_path:
  deleted_scope:
  no_touch_paths:
  oracle:
  stop_if:
```

Keep it in conversation or working notes unless the target project requires a
retained artifact.

## Mantra Gate

Before state-changing work, use the TES Mantra Gate:

```text
VERIFY -> SCOPE -> BEST_PATH -> DOCUMENT -> ORACLE -> RESOLVE -> STATUS
```

For routine writes, commits, generated artifacts, spec execution, high-risk
work, or project-state updates, show only `[🍳 Flash-Fry]` to the user when the
gate permits proceeding. That marker is UX compression, not evidence deletion:
the full gate must be recorded in the current evidence/report surface, Field
Reports/Cortex when appropriate, or the local `.tes/mantra-gates/` fallback.

Report gate detail only when the gate returns `BLOCKED` or `NEEDS_REVIEW`,
approval is required, or the user explicitly asks for audit detail. If `VERIFY`
or the required `ORACLE` is missing, stop as `BLOCKED`. If `SCOPE` or
`DOCUMENT` is ambiguous for material work, stop as `NEEDS_REVIEW`.

## Infrastructure Decision Gate

Before any infrastructure decision, run a Stack Surface Scan. This applies to
native wrappers, deployment targets, database clients, queues, crypto
primitives, build tools, hosting assumptions, and runtime-bound dependencies.

Inspect the target project's actual stack evidence before choosing: package and
lock files, framework config, runtime config, deployment preset, existing
adapters, generated output contracts, and project governance. Then check
Context7 or official documentation for the framework, runtime, or cloud surface
that owns the behavior. If evidence is missing, stale, or contradictory, stop
as `NEEDS_REVIEW` instead of guessing.

For Nuxt or Nitro projects, Nitro changes the runtime surface. Inspect the
Nitro preset, `node` target, and deployment runtime before choosing a native
OpenSSL wrapper, a pure Node DER builder, Web Crypto, or another runtime-bound
implementation. A Node-looking repository can still target edge, worker,
serverless, or compatibility layers.

The decision must name the stack evidence, documentation source, rejected
alternatives, chosen path, and smallest runtime oracle before implementation.

## Diamond Build-Test-Fail-Fix

For critical capabilities, build from the finished contract down:

1. State the final behavior.
2. Create or identify the adversarial fixture that should fail first.
3. Observe the failure.
4. Implement the smallest repair.
5. Run the gate again until it passes.

Do not call certified behavior experimental. Use `blocked`, `degraded`,
`not available`, `certified`, or `fail`.

## Workflow

1. Classify the task.
   - If authority, irreversible risk, external surface, or secret handling is
     unclear, stop and ask.
   - If the task is clear and bounded, continue.
2. Make assumptions visible.
   - Resolve safe ambiguity locally.
   - Ask only when the answer changes scope, authorization, or risk.
3. Delete scope.
   - Remove unrequested features, future-proofing, one-use abstractions, and
     optional configuration.
4. Keep edits surgical.
   - Match local style.
   - Avoid unrelated formatting, comments, or refactors.
   - Remove only orphans created by this change.
5. Verify.
   - For bugs, reproduce the failure first when practical.
   - Run the smallest relevant oracle first.
   - Run broader project gates before claiming convergence.
6. Reflect for Cortex when present.
   - If `docs/agents/cortex/CONTRACT.md` exists and the work changed durable
     decisions, contracts, commands, architecture, evidence, or recurring
     lessons, call `cortex_reflect` through MCP or run
     `python3 .tes/bin/cortex.py reflect --target . "<decision or lesson>"`.
   - Treat the result as a proposal. Do not write Cortex cells without
     explicit user authorization.
   - If the result has `curation_due=true`, call `cortex_curate_plan` through
     MCP or run `python3 .tes/bin/cortex.py curate-plan --target . --backend lexical`
     before proposing any merge, split, compaction, or rejection.
7. Respect Field Reports when present.
   - Field Reports is active by default, sanitized, and drained by the local
     pre-push hook.
   - If the user asks to disable, enable, check, or drain it, run the matching
     `field_reports.py` oracle without expanding collection levels or schema.
8. Keep feedback grounded for people.
   - Prefer short, frank prose.
   - Avoid tables, code blocks, YAML/property dumps, and long inventories unless
     the user asks or the artifact requires exact syntax.

## Module Map

| Need | Load |
|------|------|
| Mantra Gate helper | `.tes/bin/mantra_gate.py --self-test` when installed, or `scripts/mantra_gate.py --self-test` in the package source |
| Mantra Gate adoption health | `.tes/bin/mantra_gate_adoption_oracle.py --target .` when installed, or `scripts/mantra_gate_adoption_oracle.py --target .` in the package source |
| Common failure patterns | `references/failure-patterns.md` |
| Port this discipline across tools | `references/source-portability.md` |
| Deterministic self-test or plan check | `scripts/discipline_oracle.py` |

Do not bulk-load references unless the task needs them.

## Success Formula

```text
E = A * S * C * V
```

Each factor is binary at closure:

- `A`: assumptions visible
- `S`: scope simplified
- `C`: change constrained
- `V`: verification complete

If any factor is missing, success is zero and the work must stop or be repaired.

## TES Memory Lifecycle Boundary

When Cortex is the durable memory surface, keep the lifecycle boundary explicit:

- recall stays read-only unless a specific TES skill or oracle authorizes more;
- scope normalization is handled by the parent context until the shared
  normalizer exists;
- write gate means durable Cortex writes require explicit parent authorization;
- checkpoint state is resumability, not durable memory;
- closeout is proven by TES oracles and repository Git hooks;
- subagent return is evidence return only.

Parent owns durable memory. Agents may inspect, patch, or report findings inside
their assigned scope, but they must not perform durable Cortex writes or promote
checkpoint/event state into memory directly.

## Validation

Run the bundled self-test when changing this skill:

```bash
python3 .agents/skills/tes-engineering-discipline/scripts/discipline_oracle.py --self-test
```

In a target repository, also run the smallest real project oracle: unit test,
typecheck, lint, build, contract test, or governance gate.

## Done

The skill is applied when assumptions are visible, implementation is smaller
than the first impulse, every changed line traces to the request, closure is
backed by evidence, and durable learning has been considered for Cortex without
automatic writing.
