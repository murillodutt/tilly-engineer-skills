---
name: tes-mcp
description: Use when the user says /tes-mcp, /tes:mcp, or asks to activate, verify, repair, audit, or explain the read-only TES Cortex MCP server for Codex, Claude, Cursor, or all runtimes.
license: MIT
---

# TES MCP

`/tes-mcp` is the preferred shared TES trigger for project-scoped Cortex MCP
activation and health checks. `/tes:mcp` is a compatible TES intent alias if
the host reports it as an invalid slash.

## Workflow

1. Identify the selected runtime route: `current`, `codex`, `claude`,
   `cursor`, or `all`.
2. Confirm the target project path.
3. Use `install_mcp.py --dry-run` when reviewing changes.
4. Use `install_mcp.py --target <project> --adapter <route> --yes` only when
   activation is authorized.
5. Run `install_mcp.py --self-test`, `cortex_mcp.py --self-test`, or
   `install_smoke.py --route mcp` as the local oracle.
6. Report created or merged project-scoped config paths.

The read-only surface includes `cortex_verify`, `cortex_audit`,
`cortex_recall`, `cortex_read_cell`, `cortex_absorb_plan`,
`cortex_curate_plan`, and `cortex_reflect`.

## Locks

- Do not edit global MCP config.
- Do not create write-capable MCP tools.
- Do not touch secrets, env files, hooks, remotes, or cloud settings.
- Do not call MCP, SQLite, or LLM output "memory"; MCP is access only.
- Treat `.tes/bin/cortex_embed.mjs` as a local helper for optional neural
  curation, not as a memory source.
